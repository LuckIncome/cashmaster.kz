@extends('layouts.master')
@section('content')
<div class="page404 head2-1">
    <div>Страница не найдена</div>
    <a href="/">Главная</a> Страница не найдена
    Попробуйте вернуться на предыдущую страницу или начать все сначала.
</div>
<style>
    .page404 {
        padding-top: 194px;
    }
</style>
@endsection
